#include <stdio.h>

int main(void) {
    printf("Hell C!\n");

    return 0;
}
