#include <stdio.h>

int main(void){
  int a,b,x,y;
  a=15;
  b=37;
  x=a+b;
  y=a-b;

  printf("a+b= %d\n",x);
  printf("a-b= %d\n",y);

  return 0;
}
