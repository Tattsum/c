#include <stdio.h>

int main(void){
  int a,b;
  a=15;
  b=37;

  printf("%d\n",a+b);

  return 0;
}
