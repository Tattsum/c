#include <stdio.h>

int main(void){
  printf("%d \n",15+37);

  return 0;
}
