/*これは私の作ったプログラムです*/
#include <stdio.h>

int main(void) { /*main関数は最初に実行されます*/

  printf("Hello C! \n");
  return 0;
}
